import{bB as i}from"./index-DSx1SmDz.js";var e=i("product","*categories,*shipping_profile,-variants");export{e as P};
