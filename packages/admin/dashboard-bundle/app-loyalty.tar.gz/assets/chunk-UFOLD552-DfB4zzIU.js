import{bB as i}from"./index-BJ6UDC1y.js";var e=i("product","*categories,*shipping_profile,-variants");export{e as P};
