import{aw as c}from"./index-BJ6UDC1y.js";function m(o,r){const[t]=c(),s={};return o.forEach(a=>{const e=r?`${r}_${a}`:a,u=t.get(e)||void 0;s[a]=u}),s}export{m as u};
