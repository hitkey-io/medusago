import{eO as r}from"./index-DSx1SmDz.js";r("sales_channel_status",(e,a,l)=>({color:e?"grey":"green",label:l(e?"general.disabled":"general.enabled")}));
