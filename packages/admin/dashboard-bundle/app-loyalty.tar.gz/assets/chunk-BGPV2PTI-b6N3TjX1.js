import{eO as r}from"./index-BJ6UDC1y.js";r("sales_channel_status",(e,a,l)=>({color:e?"grey":"green",label:l(e?"general.disabled":"general.enabled")}));
