import{fX as t,u as r,r as u,f$ as i}from"./index-BJ6UDC1y.js";var n=()=>{const{isInstalled:e,isLoading:s}=t(i),a=r();return u.useEffect(()=>{!s&&!e&&a(-1)},[e,s,a]),e};export{n as u};
